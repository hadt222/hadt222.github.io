# Go Concurrency: Goroutine, Channel, Mutex, Context, WaitGroup

Bộ ví dụ chạy độc lập và một REST API demo Worker Pool, chỉ dùng thư viện chuẩn Go. Code tương thích Go 1.23+; phần hướng dẫn có thêm `sync.WaitGroup.Go` cho Go 1.25+.

## Khởi chạy

```bash
go version
go run ./cmd/goroutine
go run ./cmd/channel
go run ./cmd/mutex
go run ./cmd/context
go run ./cmd/waitgroup
```

## Demo Backend: batch-price API

```bash
go run ./cmd/workerpool
```

Ở terminal khác:

```bash
curl 'http://127.0.0.1:8085/prices?ids=1,2,3,4,5,6,7'
```

Endpoint nhận ID sản phẩm và xử lý tối đa 3 tác vụ `fetchPrice` tại cùng thời điểm. Các lời gọi giả lập I/O và có thể bị hủy bởi context. Giá trị ID 7 sinh lỗi ở mức từng phần tử nhưng không khiến cả batch thất bại; timeout chung 700ms trả HTTP 504. API chỉ chạy trên loopback (127.0.0.1).

- `cmd/workerpool/main.go`: HTTP route + timeout + hàm fetch giả lập.
- `internal/batch/batch.go`: worker pool kết hợp goroutine + channel + mutex + context + WaitGroup.
- `internal/batch/batch_test.go`: test số worker tối đa, sort kết quả, lỗi từng job, timeout.
- `cmd/workerpool/main_test.go`: HTTP test bằng httptest.
- `exercises/exercises.md` và `exercises/solutions.md`: bài tập và lời giải tham khảo.

## Chạy test

```bash
go test ./...
go test -race ./...
go vet ./...
go test -cover ./...
```

Để kiểm tra nhiều lần các lỗi phụ thuộc lịch chạy:

```bash
go test -race -count=10 ./internal/batch
```

Race detector chỉ tìm được data race ở những đường code thực sự được chạy. Test qua race detector không thay thế kiểm tra thiết kế của cancellation và deadlock.

## Sơ đồ thiết kế batch-price

```mermaid
flowchart TD
    A[HTTP GET /prices] --> B[Context timeout 700ms]
    B --> C[Producer: jobs channel]
    C --> D[Worker 1]
    C --> E[Worker 2]
    C --> F[Worker 3]
    D --> G[Results channel]
    E --> G
    F --> G
    G --> H[Collector + sort]
    H --> I[JSON response]
    D -. cập nhật .-> M[Stats + Mutex]
    E -. cập nhật .-> M
    F -. cập nhật .-> M
    B -. cancel .-> D
    B -. cancel .-> E
    B -. cancel .-> F
```

Các worker gọi `wg.Done()` khi kết thúc; một goroutine chờ `wg.Wait()` rồi đóng results. Producer tự đóng jobs sau khi gửi hết hoặc bị hủy.

## Quy ước cần nhớ

1. Goroutine không tự trả giá trị cho caller: dùng channel, shared state với lock, hoặc abstraction khác.
2. Sender duy nhất nên phụ trách đóng channel, sau khi bảo đảm không còn send.
3. WaitGroup chỉ đếm/chờ công việc, không truyền error hay tự hủy công việc.
4. Context hủy hợp tác: code phải lắng nghe `ctx.Done()` hoặc dùng API hỗ trợ context.
5. Mutex chỉ bảo vệ đoạn code cần thiết; tránh giữ lock trong lúc I/O hoặc gọi hệ thống chậm.
6. Khi kết thúc một pipeline sớm, phải bảo đảm mọi producer/worker có lối thoát để tránh goroutine leak.

Tài liệu chính thức: https://go.dev/doc/effective_go#concurrency ; https://pkg.go.dev/sync ; https://pkg.go.dev/context ; https://go.dev/blog/pipelines ; https://go.dev/doc/articles/race_detector
