package main

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	"example.com/go-concurrency-tutorial/internal/batch"
)

func fetchPrice(ctx context.Context, id int) (int, error) {
	// Simulate a downstream HTTP or DB call that honors cancellation.
	delay := time.Duration(100+id%3*50) * time.Millisecond
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return 0, ctx.Err()
	case <-timer.C:
		if id%7 == 0 {
			return 0, errors.New("downstream unavailable")
		}
		return id * 100, nil
	}
}

func newHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /prices", func(w http.ResponseWriter, r *http.Request) {
		raw := strings.TrimSpace(r.URL.Query().Get("ids"))
		if raw == "" {
			http.Error(w, "use /prices?ids=1,2,3", http.StatusBadRequest)
			return
		}
		values := strings.Split(raw, ",")
		if len(values) > 50 {
			http.Error(w, "max 50 ids", http.StatusBadRequest)
			return
		}
		ids := make([]int, 0, len(values))
		for _, value := range values {
			id, err := strconv.Atoi(strings.TrimSpace(value))
			if err != nil || id <= 0 {
				http.Error(w, "ids must be positive integers", http.StatusBadRequest)
				return
			}
			ids = append(ids, id)
		}

		ctx, cancel := context.WithTimeout(r.Context(), 700*time.Millisecond)
		defer cancel()
		results, stats, err := batch.Run(ctx, ids, 3, fetchPrice)
		if err != nil {
			if errors.Is(err, context.DeadlineExceeded) {
				http.Error(w, "downstream timeout", http.StatusGatewayTimeout)
			} else {
				http.Error(w, "request interrupted", http.StatusServiceUnavailable)
			}
			return
		}

		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(struct {
			Results []batch.Result `json:"results"`
			Stats   batch.Stats    `json:"stats"`
		}{Results: results, Stats: stats}); err != nil {
			log.Printf("write response: %v", err)
		}
	})
	return mux
}

func main() {
	server := &http.Server{
		Addr:              "127.0.0.1:8085",
		Handler:           newHandler(),
		ReadHeaderTimeout: 5 * time.Second,
	}
	log.Println("Try: http://127.0.0.1:8085/prices?ids=1,2,3,4,5,6,7")
	log.Fatal(server.ListenAndServe())
}
