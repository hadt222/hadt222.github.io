package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestPricesHandler(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/prices?ids=3,1,2", nil)
	w := httptest.NewRecorder()
	newHandler().ServeHTTP(w, req)
	if w.Code != http.StatusOK {
		t.Fatalf("got %d: %s", w.Code, w.Body.String())
	}
	if !strings.Contains(w.Body.String(), `"id":1`) {
		t.Fatalf("missing sorted result in %s", w.Body.String())
	}
}

func TestPricesHandlerInvalidIDs(t *testing.T) {
	req := httptest.NewRequest(http.MethodGet, "/prices?ids=1,wrong", nil)
	w := httptest.NewRecorder()
	newHandler().ServeHTTP(w, req)
	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}
