package main

import "fmt"

// Only the producer closes the channel after its last send.
func produce(out chan<- int) {
	defer close(out)
	for i := 1; i <= 5; i++ {
		out <- i * i
	}
}

func main() {
	squares := make(chan int, 2)
	go produce(squares)

	for n := range squares {
		fmt.Println("square:", n)
	}
	fmt.Println("Channel drained and closed")
}
