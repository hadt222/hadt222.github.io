package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	wg.Add(3) // Add must run before launching tasks.

	for i := 1; i <= 3; i++ {
		id := i
		go func() {
			defer wg.Done()
			fmt.Printf("Task %d finished\n", id)
		}()
	}

	wg.Wait()
	fmt.Println("All tasks finished")
}
