package main

import (
	"fmt"
	"sync"
)

func printNumbers(name string, wg *sync.WaitGroup) {
	defer wg.Done()
	for i := 1; i <= 3; i++ {
		fmt.Printf("%s: %d\n", name, i)
	}
}

func main() {
	var wg sync.WaitGroup
	wg.Add(2)
	go printNumbers("A", &wg)
	go printNumbers("B", &wg)
	wg.Wait()
	fmt.Println("All done")
}
