package batch

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
)

func TestRunBoundedConcurrentAndSorted(t *testing.T) {
	ids := []int{8, 7, 6, 5, 4, 3, 2, 1}
	var active atomic.Int32
	var peak atomic.Int32

	fetch := func(ctx context.Context, id int) (int, error) {
		now := active.Add(1)
		defer active.Add(-1)
		for {
			old := peak.Load()
			if old >= now || peak.CompareAndSwap(old, now) {
				break
			}
		}
		time.Sleep(5 * time.Millisecond)
		return id * 100, nil
	}

	got, stats, err := Run(context.Background(), ids, 3, fetch)
	if err != nil {
		t.Fatal(err)
	}
	if n := peak.Load(); n > 3 || n < 1 {
		t.Fatalf("peak concurrency = %d; want 1..3", n)
	}
	if len(got) != len(ids) || stats.Started != len(ids) || stats.Finished != len(ids) || stats.Failed != 0 {
		t.Fatalf("incorrect output len=%d stats=%+v", len(got), stats)
	}
	for i, result := range got {
		if result.ID != i+1 || result.Value != (i+1)*100 {
			t.Fatalf("got[%d]=%+v", i, result)
		}
	}
}

func TestRunCancellation(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Millisecond)
	defer cancel()
	fetch := func(ctx context.Context, id int) (int, error) {
		<-ctx.Done()
		return 0, ctx.Err()
	}

	_, _, err := Run(ctx, []int{1, 2, 3, 4, 5}, 2, fetch)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("expected deadline exceeded, got %v", err)
	}
}

func TestRunIndividualFailure(t *testing.T) {
	results, stats, err := Run(context.Background(), []int{1, 2}, 2,
		func(_ context.Context, id int) (int, error) {
			if id == 2 {
				return 0, errors.New("upstream error")
			}
			return 100, nil
		})
	if err != nil || len(results) != 2 || stats.Failed != 1 || results[1].Error != "upstream error" {
		t.Fatalf("results=%+v stats=%+v err=%v", results, stats, err)
	}
}

func TestRunValidation(t *testing.T) {
	_, _, err := Run(context.Background(), nil, 0, func(context.Context, int) (int, error) { return 0, nil })
	if err == nil {
		t.Fatal("expected invalid worker count error")
	}
}
