// Package batch demonstrates a bounded worker pool using all five
// concurrency concepts: goroutines, channels, mutex, context, WaitGroup.
package batch

import (
	"context"
	"errors"
	"sort"
	"sync"
)

// FetchFunc represents a cancellable downstream lookup.
type FetchFunc func(ctx context.Context, id int) (int, error)

type Result struct {
	ID    int    `json:"id"`
	Value int    `json:"value"`
	Error string `json:"error,omitempty"`
}

type Stats struct {
	Started  int `json:"started"`
	Finished int `json:"finished"`
	Failed   int `json:"failed"`
}

type metrics struct {
	mu    sync.Mutex
	state Stats
}

func (m *metrics) start() {
	m.mu.Lock()
	m.state.Started++
	m.mu.Unlock()
}

func (m *metrics) finish(err error) {
	m.mu.Lock()
	m.state.Finished++
	if err != nil {
		m.state.Failed++
	}
	m.mu.Unlock()
}

func (m *metrics) snapshot() Stats {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.state
}

// Run limits the number of in-flight fetches to workers. It waits for every
// spawned goroutine, and returns context errors on cancellation/deadline.
// Individual fetch failures are recorded in Result.Error and Stats.Failed.
func Run(ctx context.Context, ids []int, workers int, fetch FetchFunc) ([]Result, Stats, error) {
	if workers < 1 {
		return nil, Stats{}, errors.New("workers must be >= 1")
	}
	if fetch == nil {
		return nil, Stats{}, errors.New("fetch function must not be nil")
	}
	if err := ctx.Err(); err != nil {
		return nil, Stats{}, err
	}

	jobs := make(chan int)
	results := make(chan Result)
	var stats metrics
	var wg sync.WaitGroup

	// The producer is also counted, so no spawned task is left behind.
	wg.Add(workers + 1)
	go func() {
		defer wg.Done()
		defer close(jobs) // producer owns jobs and is its only sender
		for _, id := range ids {
			select {
			case <-ctx.Done():
				return
			case jobs <- id:
			}
		}
	}()

	for i := 0; i < workers; i++ {
		go func() {
			defer wg.Done()
			for {
				var id int
				var ok bool
				select {
				case <-ctx.Done():
					return
				case id, ok = <-jobs:
					if !ok {
						return
					}
				}

				stats.start()
				value, err := fetch(ctx, id)
				stats.finish(err)

				result := Result{ID: id, Value: value}
				if err != nil {
					result.Error = err.Error()
				}
				select {
				case <-ctx.Done():
					return
				case results <- result:
				}
			}
		}()
	}

	// A single closer waits for every sender before closing results.
	go func() {
		wg.Wait()
		close(results)
	}()

	collected := make([]Result, 0, len(ids))
	for result := range results {
		collected = append(collected, result)
	}
	if err := ctx.Err(); err != nil {
		return nil, stats.snapshot(), err
	}

	// Worker execution order is nondeterministic; API output order is stable.
	sort.SliceStable(collected, func(i, j int) bool {
		return collected[i].ID < collected[j].ID
	})
	return collected, stats.snapshot(), nil
}
