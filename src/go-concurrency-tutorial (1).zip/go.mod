module example.com/go-concurrency-tutorial

go 1.23
