# Gợi ý và lời giải tham khảo

## Bài 1

Sử dụng hai worker nhận từ `jobs`, ghi vào `results`. Một goroutine producer gửi 1..10 rồi đóng jobs. Chờ hai worker hoàn thành bằng WaitGroup, sau đó đóng `results`. Main `range results`, `sort.Slice` theo index. Chú ý không đóng results trong từng worker, vì có nhiều sender.

## Bài 2 — Mutex

```go
type Counter struct {
    mu sync.Mutex
    value int
}
func (c *Counter) Add() {
    c.mu.Lock()
    c.value++
    c.mu.Unlock()
}
```

100 goroutine, mỗi goroutine chạy `Add` 1.000 lần, `wg.Add(100)` trước lúc spawn, trong goroutine `defer wg.Done()`. Đọc `value` sau `wg.Wait()` hoặc bằng method được bảo vệ bởi cùng mutex.

Với `atomic.Int64`, dùng `counter.Add(1)` và `counter.Load()`. Không đồng thời trộn atomic và truy cập thường lên cùng một biến.

## Bài 3 — Semaphore

```go
sem := make(chan struct{}, 3)
var wg sync.WaitGroup
for _, job := range jobs {
    sem <- struct{}{} // Lấy token trước khi tạo goroutine để giới hạn cả số task đang chờ
    wg.Add(1)
    go func(job Job) {
        defer wg.Done()
        defer func() { <-sem }()
        process(job)
    }(job)
}
wg.Wait()
```

Với số job rất lớn, một fixed worker pool đơn giản hơn; xem `internal/batch/batch.go`.

## Bài 4 — Timeout

```go
func work(ctx context.Context, d time.Duration) error {
    timer := time.NewTimer(d)
    defer timer.Stop()
    select {
    case <-timer.C:
        return nil
    case <-ctx.Done():
        return ctx.Err()
    }
}
```

Tạo một timeout context và dùng chung cho cả ba công việc. Chờ tất cả bằng WaitGroup; không hủy riêng từng child context nếu muốn tất cả công việc cùng chia sẻ deadline.

## Bài 5 — Deadlock

`range ch` chờ nhận tiếp dù sender đã gửi xong ba phần tử, vì không ai đóng channel. Sửa:

```go
ch := make(chan int)
go func() {
    defer close(ch) // sender đóng channel khi đã gửi hết
    for i := 0; i < 3; i++ {
        ch <- i
    }
}()
for v := range ch {
    fmt.Println(v)
}
```

## Bài 6 — REST API

Thay `workers=3` và timeout `700*time.Millisecond` trong `cmd/workerpool/main.go` bằng các tham số `strconv.Atoi` sau khi validate giới hạn 1..5 và 100..2000. Dùng `httptest.NewRecorder()` cho input lỗi; với timeout, inject một `FetchFunc` giả có thể bị hủy để test nhanh và ổn định, thay vì phụ thuộc thời gian hệ thống. Xem `internal/batch/batch_test.go` cho ví dụ timeout context.
