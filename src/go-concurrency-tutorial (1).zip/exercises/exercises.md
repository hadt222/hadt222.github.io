# Bài tập Go Concurrency (tăng dần độ khó)

## Bài 1 — Goroutine + Channel

Cho 10 số từ 1 đến 10. Tạo 2 worker nhận số từ channel, tính bình phương và gửi kết quả vào một channel khác. In các kết quả theo thứ tự số đầu vào. Không dùng Sleep để đợi công việc xong. Gợi ý: lưu `{index, square}` rồi sort theo index.

## Bài 2 — Mutex

Một Counter có 100 goroutine, mỗi goroutine tăng biến đếm 1.000 lần. Bảo đảm kết quả bằng 100.000 và qua `go run -race` / `go test -race`. Thử hai cách: sync.Mutex và atomic.Int64. Giải thích vì sao `value++` không an toàn khi chạy đồng thời.

## Bài 3 — Bounded concurrency

Xử lý 20 công việc I/O giả lập. Không được có quá 3 công việc đang thực thi cùng lúc. Cách A: worker pool 3 goroutine; cách B: semaphore buffered channel có capacity 3. Không được tạo số goroutine không giới hạn khi số job rất lớn.

## Bài 4 — Context cancellation

Tạo một context timeout 250ms. Chạy các công việc giả lập mất 100ms, 300ms, 500ms. Mỗi công việc phải tự thoát khi context bị hủy. Chờ tất cả goroutine hoàn thành rồi in `ctx.Err()`. Dùng `time.NewTimer` + `select`.

## Bài 5 — Debug deadlock

Đoạn sau treo ở đâu? Vì sao? Sửa lại mà không dùng Sleep:

```go
ch := make(chan int)
go func() {
    for i := 0; i < 3; i++ {
        ch <- i
    }
}()
for v := range ch {
    fmt.Println(v)
}
```

## Bài 6 — Mini-project Backend

Dựa trên `cmd/workerpool`, mở rộng API `GET /prices?ids=...`:

- Thêm query parameter `workers`, cho phép từ 1 đến 5.
- Thêm query parameter `timeout_ms` từ 100 đến 2000.
- Gắn `context.WithTimeout(r.Context(), timeout)`.
- Trả JSON kết quả có trường `stats`.
- Viết unit test với `httptest` cho input sai và timeout.
- Chạy `go test -race ./...`.

**Nâng cao:** cho phép trả kết quả từng phần khi một job lỗi nhưng hủy toàn bộ batch khi context hết hạn. Thêm một test kiểm tra không có job mới được bắt đầu sau khi hủy.
