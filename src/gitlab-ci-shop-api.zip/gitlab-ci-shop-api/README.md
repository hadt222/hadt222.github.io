# GitLab CI/CD shop-api — end-to-end example

A small Node.js HTTP API with real syntax checks, two integration-style HTTP tests,
Docker packaging, GitLab Container Registry publishing, and SSH/Docker Compose deployment.
The source code uses only built-in Node.js modules to make the demo reproducible.

## Run locally

```bash
npm ci
npm run lint
npm test
npm start
# In another terminal:
curl http://localhost:3000/health
```

## Expected branches and pipeline

* Feature branches + merge requests: lint and test.
* `develop` pushes: lint -> test -> Docker build/push -> automatic staging deployment.
* `main` pushes: lint -> test -> Docker build/push -> manual production deployment.

The image tag is `$CI_REGISTRY_IMAGE:$CI_COMMIT_SHA`.

## Runner requirements

`build_image` requests a dedicated runner tagged `docker-build`, configured with the
Docker executor, privileged mode and `/certs/client` shared volume for Docker-in-Docker TLS.
Do not expose that runner to untrusted pipelines; make both `develop` and `main` protected.
The remaining jobs need any untagged, unprivileged runner, or a GitLab-hosted runner.

## GitLab project variables

In Settings > CI/CD > Variables, create **project** variables with these same names
*twice*, with environment scopes `staging` and `production`:

- `DEPLOY_HOST` — target VPS DNS/IP, ordinary variable
- `DEPLOY_USER` — dedicated SSH user, e.g. `deploy`, ordinary variable
- `SSH_PRIVATE_KEY` — file variable, private Ed25519 deployment key with trailing LF
- `SSH_KNOWN_HOSTS` — file variable, verified known_hosts entry for the VPS

Use **Protected** for secrets, and protect both the `develop` and `main` branches.
Do not print private keys in logs. Private SSH file variables normally use Visible
visibility because multi-line private keys cannot be masked.
Use unique SSH keys for staging and production if possible.

## VPS preparation (repeat on staging and production hosts)

1. Install Docker Engine with the Docker Compose plugin, then create a dedicated `deploy`
   user that can run Docker (membership of the `docker` group is effectively root access).
2. Configure the CI public SSH key in `/home/deploy/.ssh/authorized_keys`.
3. Prepare the deployment directory and a server-local environment file:

```bash
sudo install -d -o deploy -g deploy -m 700 /opt/shop-api
sudo -u deploy sh -c 'printf "APP_GREETING=Hello from this VPS\n" > /opt/shop-api/runtime.env'
sudo chmod 600 /opt/shop-api/runtime.env
```

4. In GitLab Project > Settings > Repository > Deploy tokens, create a token with
   **read_registry only** (or use the actual deploy-token page for your GitLab version).
   As the `deploy` user on the VPS, run:

```bash
read -r -s -p 'Registry token: ' REGISTRY_TOKEN; echo
printf '%s' "$REGISTRY_TOKEN" | docker login registry.gitlab.com \
  -u '<DEPLOY_TOKEN_USERNAME>' --password-stdin
unset REGISTRY_TOKEN
```

Change `registry.gitlab.com` for self-managed GitLab. Docker stores local auth
credentials, so protect the `deploy` account and its Docker config; rotate the token.

5. Configure a reverse proxy with HTTPS (for example Nginx + valid certificates)
   to forward public traffic to `127.0.0.1:3000`. Port 3000 is intentionally private.
   The `deploy/compose.yaml` file is copied to the VPS automatically during deployment.

## GitLab validation

Use Project > Build > Pipeline editor > Validate. GitLab's CI Lint catches conditions
and semantic errors that generic YAML parsers cannot detect.

## Manual rollback

Find a previously published, healthy image tag, then on the VPS:

```bash
IMAGE='registry.gitlab.com/GROUP/PROJECT:<PREVIOUS_COMMIT_SHA>' \
  docker compose -f /opt/shop-api/compose.yaml up -d --pull always --wait --wait-timeout 120
```

This returns the app container to the selected image, but **does not roll back
DB migrations or data**. For production, control access to old-pipeline manual jobs
and prefer promotion by immutable image digest for stricter artifact provenance.

## Notes

- This demo's `lint` script performs Node.js syntax checks; use ESLint or a more
  comprehensive linter for production.
- The example uses Docker-in-Docker with privileged Runner for clarity. Use isolated,
  protected runners; consider rootless BuildKit or equivalent for stricter security.
- Docker and VPS deployments were not executed in the artifact-creation environment.
