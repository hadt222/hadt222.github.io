'use strict';
const http = require('node:http');

function createServer() {
  return http.createServer((req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    if (req.method === 'GET' && req.url === '/health') {
      res.writeHead(200);
      return res.end(JSON.stringify({ status: 'ok' }));
    }
    if (req.method === 'GET' && req.url === '/') {
      res.writeHead(200);
      return res.end(JSON.stringify({ name: 'shop-api', greeting: process.env.APP_GREETING || 'Hello from GitLab CI/CD' }));
    }
    res.writeHead(404);
    res.end(JSON.stringify({ error: 'not found' }));
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT || 3000);
  createServer().listen(port, '0.0.0.0', () => console.log(`shop-api listening on port ${port}`));
}
module.exports = { createServer };
