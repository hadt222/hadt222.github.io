import { readFile } from 'node:fs/promises';
import { pool } from '../src/config/db.js';

try {
  const path = new URL('../db/migrations/001_create_tasks.sql', import.meta.url);
  const sql = await readFile(path, 'utf8');
  await pool.query(sql);
  console.log('Database migration completed.');
} catch (error) {
  console.error('Migration failed:', error);
  process.exitCode = 1;
} finally {
  await pool.end();
}
