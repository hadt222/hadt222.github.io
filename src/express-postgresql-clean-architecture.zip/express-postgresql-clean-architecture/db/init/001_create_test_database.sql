-- Chạy một lần khi Docker tạo database volume mới.
CREATE DATABASE tasks_db_test;
