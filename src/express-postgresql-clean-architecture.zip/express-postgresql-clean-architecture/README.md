# Express.js + PostgreSQL: Controller / Service / Repository

Yêu cầu: Node.js >= 22, Docker Compose (hoặc PostgreSQL có sẵn).

## Khởi chạy nhanh

```bash
npm install
cp .env.example .env
cp .env.test.example .env.test
# Nếu dùng Docker:
docker compose up -d
npm run db:migrate
npm run db:migrate:test
npm run dev
```

API: http://localhost:3000

- GET /health
- GET /ready
- GET /api/tasks?completed=false&page=1&limit=10
- GET /api/tasks/:id
- POST /api/tasks
- PATCH /api/tasks/:id
- DELETE /api/tasks/:id

Ví dụ:

```bash
curl -X POST http://localhost:3000/api/tasks \
  -H 'Content-Type: application/json' \
  -d '{"title":"Learn PostgreSQL","description":"Use repositories"}'
```

## Kiểm thử

```bash
npm test
```

**Cảnh báo:** `.env.test` phải chỉ tới database có tên kết thúc bằng `_test`. Test thực hiện INSERT/UPDATE/DELETE. Không chạy test trên database chứa dữ liệu thật.

Script migration 001 có thể chạy lại nhờ `IF NOT EXISTS`. Trong production nên sử dụng hệ thống quản lý lịch sử migration chuyên dụng.

Docker chỉ khởi tạo database test ở lần đầu tạo volume. Nếu đang tái sử dụng volume cũ, bạn phải tạo database test thủ công hoặc sử dụng volume mới. Không xóa Docker volume khi chứa dữ liệu cần giữ.

## Cấu trúc

- `routes`: URL + method + validation middleware
- `controllers`: HTTP request/response
- `services`: business rules
- `repositories`: SQL queries
- `schemas`: Zod schemas
- `middleware`: validation / errors
- `config/db.js`: PostgreSQL pool
- `scripts/migrate.js`: chạy SQL migration
- `tests`: integration tests qua Supertest + PostgreSQL riêng
