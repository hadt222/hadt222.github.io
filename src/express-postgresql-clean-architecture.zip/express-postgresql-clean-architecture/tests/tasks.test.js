import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../src/app.js';
import { pool } from '../src/config/db.js';

after(async () => {
  await pool.end();
});

test('Create, read, update, filter and delete a task', async () => {
  const created = await request(app)
    .post('/api/tasks')
    .send({ title: 'Integration test', description: 'From Supertest' })
    .expect(201);

  const id = created.body.data.id;
  assert.equal(created.body.data.completed, false);

  try {
    const fetched = await request(app)
      .get(`/api/tasks/${id}`)
      .expect(200);
    assert.equal(fetched.body.data.title, 'Integration test');

    const updated = await request(app)
      .patch(`/api/tasks/${id}`)
      .send({ completed: true })
      .expect(200);
    assert.equal(updated.body.data.completed, true);

    const listed = await request(app)
      .get('/api/tasks?completed=true&page=1&limit=10')
      .expect(200);
    assert.ok(listed.body.data.some((task) => task.id === id));
    assert.equal(listed.body.pagination.page, 1);

    await request(app).delete(`/api/tasks/${id}`).expect(204);
    await request(app).get(`/api/tasks/${id}`).expect(404);
  } finally {
    // Dọn dữ liệu nếu một assertion phía trên thất bại.
    await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
  }
});

test('Reject invalid payload and invalid ID', async () => {
  await request(app)
    .post('/api/tasks')
    .send({ title: '' })
    .expect(400);

  await request(app)
    .patch('/api/tasks/1')
    .send({})
    .expect(400);

  await request(app).get('/api/tasks/not-a-number').expect(400);
  await request(app).get('/api/tasks?limit=999').expect(400);
});

test('Respond to liveness and readiness checks', async () => {
  await request(app).get('/health').expect(200);
  await request(app).get('/ready').expect(200);
});
