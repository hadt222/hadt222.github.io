import { taskService } from '../services/task.service.js';

export const taskController = {
  async list(req, res) {
    const query = res.locals.input.query;
    const { items, total } = await taskService.list(query);

    res.json({
      success: true,
      data: items,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit)
      }
    });
  },

  async getById(req, res) {
    const task = await taskService.getById(res.locals.input.params.id);
    res.json({ success: true, data: task });
  },

  async create(req, res) {
    const task = await taskService.create(res.locals.input.body);
    res.location(`/api/tasks/${task.id}`)
      .status(201)
      .json({ success: true, data: task });
  },

  async update(req, res) {
    const task = await taskService.update(
      res.locals.input.params.id,
      res.locals.input.body
    );
    res.json({ success: true, data: task });
  },

  async remove(req, res) {
    await taskService.remove(res.locals.input.params.id);
    res.status(204).end();
  }
};
