import { pool } from '../config/db.js';

const TASK_COLUMNS =
  'id, title, description, completed, created_at, updated_at';

export const taskRepository = {
  async findMany({ completed, page, limit }) {
    const where = completed === undefined
      ? ''
      : 'WHERE completed = $1';
    const filterValues = completed === undefined ? [] : [completed];

    const values = [...filterValues, limit, (page - 1) * limit];
    const limitPosition = values.length - 1;
    const offsetPosition = values.length;

    const listSql = `
      SELECT ${TASK_COLUMNS}
      FROM tasks
      ${where}
      ORDER BY created_at DESC, id DESC
      LIMIT $${limitPosition}
      OFFSET $${offsetPosition}
    `;

    const countSql = `SELECT COUNT(*)::int AS total FROM tasks ${where}`;

    const [itemsResult, countResult] = await Promise.all([
      pool.query(listSql, values),
      pool.query(countSql, filterValues)
    ]);

    return {
      items: itemsResult.rows,
      total: countResult.rows[0].total
    };
  },

  async findById(id) {
    const result = await pool.query(
      `SELECT ${TASK_COLUMNS} FROM tasks WHERE id = $1`,
      [id]
    );
    return result.rows[0] ?? null;
  },

  async create({ title, description, completed }) {
    const result = await pool.query(
      `INSERT INTO tasks (title, description, completed)
       VALUES ($1, $2, $3)
       RETURNING ${TASK_COLUMNS}`,
      [title, description, completed]
    );
    return result.rows[0];
  },

  async update(id, changes) {
    const setters = [];
    const values = [];

    // Danh sách cột cố định, không đưa tên cột do client gửi vào SQL.
    for (const column of ['title', 'description', 'completed']) {
      if (Object.hasOwn(changes, column)) {
        values.push(changes[column]);
        setters.push(`${column} = $${values.length}`);
      }
    }

    setters.push('updated_at = NOW()');
    values.push(id);

    const result = await pool.query(
      `UPDATE tasks
       SET ${setters.join(', ')}
       WHERE id = $${values.length}
       RETURNING ${TASK_COLUMNS}`,
      values
    );

    return result.rows[0] ?? null;
  },

  async remove(id) {
    const result = await pool.query(
      'DELETE FROM tasks WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rowCount > 0;
  }
};
