import { Router } from 'express';
import { taskController } from '../controllers/task.controller.js';
import { validate } from '../middleware/validate.js';
import {
  taskParamsSchema,
  listTasksQuerySchema,
  createTaskSchema,
  updateTaskSchema
} from '../schemas/task.schema.js';

const router = Router();

router.get('/', validate(listTasksQuerySchema, 'query'), taskController.list);
router.get('/:id', validate(taskParamsSchema, 'params'), taskController.getById);
router.post('/', validate(createTaskSchema), taskController.create);
router.patch(
  '/:id',
  validate(taskParamsSchema, 'params'),
  validate(updateTaskSchema),
  taskController.update
);
router.delete('/:id', validate(taskParamsSchema, 'params'), taskController.remove);

export default router;
