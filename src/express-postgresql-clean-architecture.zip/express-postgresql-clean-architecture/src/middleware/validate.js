import { AppError } from '../errors/app-error.js';

export function validate(schema, source = 'body') {
  return (req, res, next) => {
    const result = schema.safeParse(req[source]);

    if (!result.success) {
      const details = result.error.issues.map((issue) => ({
        field: issue.path.join('.') || source,
        message: issue.message
      }));

      throw new AppError(400, 'Invalid request data', details);
    }

    // Lưu dữ liệu đã parse vào res.locals, không ghi đè req.query.
    res.locals.input ??= {};
    res.locals.input[source] = result.data;
    next();
  };
}
