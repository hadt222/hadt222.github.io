import { AppError } from '../errors/app-error.js';

export function notFound(req, res, next) {
  next(new AppError(404, 'Endpoint not found'));
}

export function errorHandler(err, req, res, next) {
  if (res.headersSent) {
    return next(err);
  }

  // Lỗi JSON parser từ express.json().
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({
      success: false,
      error: { message: 'Invalid JSON body' }
    });
  }

  if (err.type === 'entity.too.large') {
    return res.status(413).json({
      success: false,
      error: { message: 'Request body too large' }
    });
  }

  const knownError = err instanceof AppError;
  const statusCode = knownError ? err.statusCode : 500;

  if (!knownError) {
    console.error('Unexpected server error:', err);
  }

  res.status(statusCode).json({
    success: false,
    error: {
      message: knownError ? err.message : 'Internal server error',
      ...(knownError && err.details ? { details: err.details } : {})
    }
  });
}
