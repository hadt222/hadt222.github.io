import 'dotenv/config';
import pg from 'pg';

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('Missing DATABASE_URL environment variable');
}

// Tránh chạy test/migration test vào database phát triển hoặc production.
if (process.env.NODE_ENV === 'test') {
  const databaseName = decodeURIComponent(
    new URL(process.env.DATABASE_URL).pathname.slice(1)
  );
  if (!databaseName.endsWith('_test')) {
    throw new Error('Test database name must end with _test');
  }
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000
});

// Bắt lỗi bất ngờ từ client đang rảnh trong pool.
pool.on('error', (error) => {
  console.error('Unexpected PostgreSQL pool error:', error);
});
