import { taskRepository } from '../repositories/task.repository.js';
import { AppError } from '../errors/app-error.js';

export const taskService = {
  async list(query) {
    return taskRepository.findMany(query);
  },

  async getById(id) {
    const task = await taskRepository.findById(id);
    if (!task) {
      throw new AppError(404, 'Task not found');
    }
    return task;
  },

  async create(data) {
    return taskRepository.create(data);
  },

  async update(id, changes) {
    const task = await taskRepository.update(id, changes);
    if (!task) {
      throw new AppError(404, 'Task not found');
    }
    return task;
  },

  async remove(id) {
    const deleted = await taskRepository.remove(id);
    if (!deleted) {
      throw new AppError(404, 'Task not found');
    }
  }
};
