import { z } from 'zod';

const positiveDecimal = z.string()
  .regex(/^[1-9]\d*$/, 'Must be a positive integer')
  .transform(Number)
  .pipe(z.int().positive());

export const taskParamsSchema = z.strictObject({
  id: positiveDecimal.pipe(z.number().max(2147483647))
});

export const listTasksQuerySchema = z.strictObject({
  completed: z.enum(['true', 'false'])
    .transform((value) => value === 'true')
    .optional(),
  page: positiveDecimal.default(1),
  limit: positiveDecimal.pipe(z.number().max(100)).default(10)
});

export const createTaskSchema = z.strictObject({
  title: z.string().trim().min(1).max(120),
  description: z.string().trim().max(2000).default(''),
  completed: z.boolean().default(false)
});

export const updateTaskSchema = z.strictObject({
  title: z.string().trim().min(1).max(120).optional(),
  description: z.string().trim().max(2000).optional(),
  completed: z.boolean().optional()
}).refine((data) => Object.keys(data).length > 0, {
  message: 'Provide at least one field to update'
});
