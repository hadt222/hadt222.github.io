import app from './app.js';
import { pool } from './config/db.js';

const PORT = Number(process.env.PORT || 3000);

async function start() {
  if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
    throw new Error('PORT must be an integer between 1 and 65535');
  }

  // Kiểm tra database sẵn sàng trước khi mở HTTP server.
  await pool.query('SELECT 1');

  const server = app.listen(PORT, () => {
    console.log(`API running at http://localhost:${PORT}`);
  });

  function shutdown(signal) {
    console.log(`Received ${signal}; shutting down`);
    server.close(async (error) => {
      if (error) {
        console.error('HTTP server shutdown error:', error);
        process.exitCode = 1;
      }
      try {
        await pool.end();
      } catch (dbError) {
        console.error('Database shutdown error:', dbError);
        process.exitCode = 1;
      }
    });
  }

  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
}

start().catch(async (error) => {
  console.error('Failed to start API:', error);
  process.exitCode = 1;
  await pool.end();
});
