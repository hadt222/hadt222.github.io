import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';

import { pool } from './config/db.js';
import taskRoutes from './routes/task.routes.js';
import { errorHandler, notFound } from './middleware/error-handler.js';

const app = express();

app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '100kb' }));

// Liveness: HTTP server đang hoạt động.
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Readiness: có thể thực hiện truy vấn vào PostgreSQL.
app.get('/ready', async (req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ready' });
});

app.use('/api/tasks', taskRoutes);
app.use(notFound);
app.use(errorHandler);

export default app;
