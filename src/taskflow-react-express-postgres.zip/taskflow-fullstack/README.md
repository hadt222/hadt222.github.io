# TaskFlow — Full-stack React + Express.js + PostgreSQL

Ứng dụng quản lý công việc dùng React 19 + Vite 7, Express 5 (Controller → Service → Repository), PostgreSQL 17. Đây là ứng dụng demo **không có authentication**: mọi người dùng truy cập API công khai đều có thể xem/sửa/xóa toàn bộ task. Không lưu dữ liệu nhạy cảm.

## 1. Tính năng

- Tạo/sửa/xóa task; đánh dấu hoàn thành
- Title, description, priority (low/medium/high), due date, status
- Tìm kiếm, lọc trạng thái và ưu tiên, phân trang
- Thống kê tổng task, đang làm, hoàn thành, quá hạn
- Validation bằng Zod, lỗi HTTP theo cấu trúc JSON, query có tham số chống SQL injection
- PostgreSQL migrations và Supertest integration tests
- Vite proxy khi phát triển local và biến môi trường cho deployment

## 2. Kiến trúc

```text
Browser (React + Vite :5173)
        | HTTP JSON /api (Vite proxy ở local)
        v
Express API (:4000) → Router → Validate → Controller → Service → Repository
                                                        |
                                                        v
                                                   PostgreSQL :5433
```

Cấu trúc thư mục:

```text
taskflow-fullstack/
├── compose.yaml
├── db/init/01-test-db.sql
├── api/
│   ├── .env.example, .env.test.example, package.json
│   ├── db/migrations/001_create_tasks.sql
│   ├── scripts/migrate.js
│   ├── tests/tasks.test.js
│   └── src/
│       ├── app.js, server.js
│       ├── config/db.js
│       ├── controllers/task.controller.js
│       ├── services/task.service.js
│       ├── repositories/task.repository.js
│       ├── routes/task.routes.js
│       ├── middleware/error.js, validate.js
│       └── schemas/task.schema.js
└── web/
    ├── .env.example, package.json, vite.config.js, index.html
    ├── public/favicon.svg
    └── src/
        ├── main.jsx, App.jsx, styles.css
        ├── components/TaskForm.jsx, TaskCard.jsx
        └── lib/api.js
```

## 3. Yêu cầu môi trường

- Node.js **22.12+** (hoặc phiên bản hỗ trợ tương đương)
- npm
- Docker + Docker Compose (hoặc PostgreSQL 17 cài trực tiếp)
- Git cho deployment

Kiểm tra:

```bash
node -v
npm -v
docker compose version
```

## 4. Chạy local từ đầu (3 terminal)

### Terminal 1 — PostgreSQL

Từ **thư mục gốc** `taskflow-fullstack`:

```bash
docker compose up -d
docker compose ps
```

Docker tải PostgreSQL 17 và tạo volume `pgdata`, database `task_manager`. Script `db/init/01-test-db.sql` tạo database `task_manager_test` trong lần đầu khởi tạo **volume mới**. Database được publish ra port `localhost:5433` để tránh đụng với PostgreSQL có sẵn ở `5432`.

**Không dùng tài khoản/mật khẩu mẫu của Docker Compose khi triển khai Internet.**

### Terminal 2 — Express backend

```bash
cd api
cp .env.example .env
cp .env.test.example .env.test
npm install
npm run db:migrate
npm run db:migrate:test
npm run dev
```

Windows PowerShell thay `cp` bằng `Copy-Item` (cú pháp `cp` cũng thường là alias có sẵn).

Kiểm tra backend:

```bash
curl http://localhost:4000/health
curl http://localhost:4000/ready
curl http://localhost:4000/api/tasks
```

- `/health`: HTTP server hoạt động.
- `/ready`: backend truy cập được PostgreSQL.
- `/api/tasks`: JSON list từ database.

### Terminal 3 — React frontend

```bash
cd web
cp .env.example .env
npm install
npm run dev
```

Mở **http://localhost:5173**. Trong local, `VITE_API_URL=` (rỗng); Vite proxy các request `/api` về `http://localhost:4000`. Điều này tránh phải hardcode backend localhost URL vào code React và giúp giữ cách gọi `/api/...` nhất quán.

> Nếu `.env` của web có `VITE_API_URL=https://...`, sẽ gọi remote API thay vì proxy local. Khi chỉnh `.env`, restart Vite.

## 5. Khám phá nghiệp vụ

### API endpoints

| Method | Path | Chức năng |
|---|---|---|
| GET | `/health` | Liveness |
| GET | `/ready` | Readiness / PostgreSQL |
| GET | `/api/tasks` | Danh sách, tìm kiếm, lọc, phân trang |
| GET | `/api/tasks/stats` | Thống kê toàn bộ task |
| GET | `/api/tasks/:id` | Xem 1 task |
| POST | `/api/tasks` | Tạo task |
| PATCH | `/api/tasks/:id` | Cập nhật một phần |
| DELETE | `/api/tasks/:id` | Xóa task |

Ví dụ tạo:

```bash
curl -i -X POST http://localhost:4000/api/tasks \
  -H 'Content-Type: application/json' \
  -d '{"title":"Học React","description":"Hoàn thiện UI","priority":"high","due_date":"2027-01-31"}'
```

Lọc:

```bash
curl 'http://localhost:4000/api/tasks?q=React&status=active&priority=high&page=1&limit=8'
```

Cập nhật:

```bash
curl -i -X PATCH http://localhost:4000/api/tasks/1 \
  -H 'Content-Type: application/json' -d '{"completed":true}'
```

Xóa:

```bash
curl -i -X DELETE http://localhost:4000/api/tasks/1
```

**Dữ liệu Task:**

```json
{
  "id": 1,
  "title": "Học React",
  "description": "Hoàn thiện UI",
  "priority": "high",
  "due_date": "2027-01-31",
  "completed": false,
  "created_at": "2026-11-09T19:00:00.000Z",
  "updated_at": "2026-11-09T19:00:00.000Z"
}
```

`created_at/updated_at` là timestamp minh họa; thực tế PostgreSQL sinh theo thời gian của server.

**HTTP status:** 200 GET/PATCH; 201 POST; 204 DELETE; 400 validation; 404 missing resource; 500 unexpected server errors.

## 6. Mô hình 3 tầng — học theo thứ tự

1. `api/src/routes/task.routes.js`: ghép method+path với middleware và controller. `GET /stats` đặt trước `GET /:id`.
2. `api/src/middleware/validate.js` và `api/src/schemas/task.schema.js`: parse query/body/params, trả 400 khi lỗi. Giá trị đã parse được lưu trong `res.locals.validated`.
3. `api/src/controllers/task.controller.js`: gọi Service, quyết định status HTTP và JSON.
4. `api/src/services/task.service.js`: nơi xử lý nghiệp vụ, ném `AppError(404, ...)` khi không tìm thấy task.
5. `api/src/repositories/task.repository.js`: SQL, tìm kiếm, lọc, thống kê, phân trang, CRUD và bind parameters (`$1`, `$2`, ...).
6. `api/src/config/db.js`: PostgreSQL connection pool dùng chung.
7. `api/src/middleware/error.js`: lỗi tập trung, không tiết lộ nội bộ cho client.

**Data flow tạo task:** Form → `taskApi.create()` → POST `/api/tasks` → Router → Zod → Controller → Service → Repository → `INSERT ... RETURNING` → HTTP 201 → React reload danh sách + số liệu.

**Data flow tìm kiếm:** React debounce 300ms → GET `/api/tasks?q=...` → query đã validate → Repository `POSITION(LOWER($1) IN LOWER(title))` → JSON pagination → React render.

Repository chỉ nhận các giá trị được validate; tên cột cập nhật chọn từ whitelist hardcode. Không bao giờ nối trực tiếp input từ người dùng vào câu SQL.

## 7. Kiểm thử backend

```bash
cd api
npm run db:migrate:test
npm test
```

Các test tạo/xóa dữ liệu trong **task_manager_test** và chạy `TRUNCATE tasks RESTART IDENTITY` trước mỗi test. Không chạy bằng production database. Script bảo vệ bằng `NODE_ENV=test` và quy tắc database phải có tên kết thúc `_test`.

Nếu dùng npm cài dependency lần đầu, nên commit `api/package-lock.json` và `web/package-lock.json` vào Git để build tái lập được. Các lockfile không kèm sẵn trong archive vì công cụ tạo project không truy cập npm registry.

## 8. Build React trước khi deploy

```bash
cd web
npm run build
npm run preview
```

Mặc định Vite tạo thư mục `web/dist`. Đó là artifact để deploy Static Site, không phải Express server. Preview chỉ phục vụ kiểm tra local; không dùng làm production web server.

## 9. Deploy lên Render: PostgreSQL + Express + React

### Chuẩn bị GitHub

Tạo repo GitHub mới, rồi từ thư mục root:

```bash
git init
git add .
git commit -m 'Build TaskFlow full-stack app'
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/taskflow-fullstack.git
git push -u origin main
```

Đảm bảo `.env` và `.env.test` không có trong commit (`.gitignore`).

### Bước A — Tạo PostgreSQL

1. Truy cập https://dashboard.render.com/.
2. Chọn **New → Postgres**, đặt tên database, chọn region và plan phù hợp. Giá / giới hạn plan có thể thay đổi; kiểm tra dashboard trước khi tạo.
3. Sau khi database sẵn sàng, lấy **Internal Database URL**. Nên đặt backend cùng region và cùng workspace/account để dùng mạng nội bộ.

### Bước B — Deploy Express API dưới dạng Web Service

1. Chọn **New → Web Service**, kết nối GitHub repo.
2. Chọn `Root Directory = api` (monorepo).
3. Runtime/Language: `Node`.
4. Build Command: `npm install` (hoặc `npm ci` sau khi commit lockfile).
5. Start Command: `npm run start:deploy`.
6. Đặt environment variables:

   | Key | Value |
   |---|---|
   | `NODE_ENV` | `production` |
   | `DATABASE_URL` | Internal Database URL từ bước A |
   | `FRONTEND_ORIGIN` | URL frontend Render từ bước C, ví dụ `https://your-taskflow.onrender.com` |

7. Nếu thiết lập health check path, đặt `/ready`. API phải listen trên `0.0.0.0` và port `process.env.PORT`; source đã hỗ trợ.
8. Deploy. Sau khi thành công, kiểm tra `https://your-api.onrender.com/health` và `/ready`.

**Migrations khi deploy:** `start:deploy` chạy migration trước khi start Express. `scripts/migrate.js` lưu danh sách migration đã áp dụng trong bảng `schema_migrations` và dùng PostgreSQL advisory transaction lock để tránh 2 tiến trình chạy migration chồng chéo. Đây là lựa chọn tiện lợi cho demo hoặc một instance; với hệ thống production lớn nên đưa migration vào pre-deploy job/pipeline riêng, bảo đảm migration backward-compatible trước khi roll out nhiều instance.

> `FRONTEND_ORIGIN` cần chính xác origin frontend (không có dấu `/` ở cuối). Bạn có thể cập nhật biến này và redeploy sau khi đã tạo frontend. Nếu muốn thử backend bằng curl/Postman thì không cần CORS, vì chúng không thực thi chính sách CORS của trình duyệt.

### Bước C — Deploy React dưới dạng Static Site

1. Chọn **New → Static Site**, kết nối cùng GitHub repo.
2. `Root Directory = web`.
3. Build Command: `npm install && npm run build` (hoặc `npm ci && npm run build` nếu có lockfile).
4. Publish Directory: `dist`.
5. Environment variable:

   | Key | Value |
   |---|---|
   | `VITE_API_URL` | `https://your-api.onrender.com` |

6. Deploy. Mở URL `https://your-taskflow.onrender.com` được Render cung cấp.
7. Quay lại backend và sửa `FRONTEND_ORIGIN` thành URL vừa được cấp, sau đó redeploy backend nếu trước đó dùng giá trị tạm.
8. Làm thử: Tạo task → reload trang → task vẫn còn, đánh dấu hoàn thành → cập nhật số liệu → xóa.

**Chú ý:** `VITE_API_URL` phải là URL API công khai (frontend chạy trong trình duyệt); `DATABASE_URL` là URL private giữa backend và PostgreSQL, không đưa vào frontend. Các biến `VITE_*` sẽ được đưa vào bundle build React nên tuyệt đối không chứa password, secret hoặc credential.

### Luồng sau deployment

```text
https://taskflow-frontend.onrender.com (Static Site)
      | HTTPS fetch('/api/tasks') qua VITE_API_URL
      v
https://taskflow-backend.onrender.com (Web Service)
      | DATABASE_URL (nội bộ)
      v
Render PostgreSQL (cùng region)
```

**Lưu ý phí và hiệu năng:** các plan, giới hạn tài nguyên và chính sách free/spin-down có thể thay đổi. Kiểm tra bảng giá Render hiện hành trước khi sử dụng. Các web service free (nếu đang khả dụng) có thể ngủ khi không có request và cần khởi động lại ở lần gọi đầu.

## 10. Lỗi thường gặp

| Hiện tượng | Nguyên nhân / cách xử lý |
|---|---|
| `ECONNREFUSED :5433` | Docker chưa chạy; thử `docker compose ps` |
| `relation "tasks" does not exist` | Chưa chạy `npm run db:migrate` |
| `database "task_manager_test" does not exist` | Volume cũ không chạy init SQL; tự tạo test DB hoặc dùng volume mới (không xóa dữ liệu quan trọng) |
| React hiển thị `Không thể kết nối API` | Backend chưa bật, sai `VITE_API_URL` hoặc deploy backend chưa xong |
| CORS error trên trình duyệt | `FRONTEND_ORIGIN` khác URL frontend (scheme/domain/port), hoặc backend đang lỗi |
| `404 /api/tasks` ở frontend | Vite proxy chưa chạy, sai path, thiếu `/api` |
| Render không phát hiện port | Phải bind `0.0.0.0:$PORT`; source đã thực hiện |
| Bấm lưu nhận 400 | Kiểm tra title 1–120 ký tự, priority, YYYY-MM-DD, kiểu boolean |
| Migrations thất bại | Kiểm tra `DATABASE_URL`, quyền `CREATE TABLE`, log deploy |

## 11. Những điều cần bổ sung trước khi dùng production nhiều người

Ứng dụng hiện tại **không có xác thực**. CORS **không** bảo vệ API trước truy cập trái phép. Trước khi lưu dữ liệu người dùng thật cần bổ sung: đăng ký/đăng nhập, JWT hoặc session được bảo vệ, phân quyền theo `user_id`, rate limiting, logging và monitoring, bảo vệ dữ liệu cá nhân, migration tương thích ngược, bảo trì backup/restore và test riêng cho quyền truy cập.

## 12. Nguồn tham khảo chính thức

- https://vite.dev/guide/
- https://vite.dev/guide/static-deploy.html
- https://expressjs.com/en/5x/guide/error-handling/
- https://node-postgres.com/features/queries
- https://node-postgres.com/features/pooling
- https://render.com/docs/multi-service-architecture
- https://render.com/docs/postgresql-creating-connecting
- https://render.com/docs/web-services
