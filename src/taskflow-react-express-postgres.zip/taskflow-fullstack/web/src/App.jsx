import { useEffect, useState } from 'react';
import { taskApi } from './lib/api.js';
import TaskCard from './components/TaskCard.jsx';
import TaskForm from './components/TaskForm.jsx';

const initialPagination = { page: 1, limit: 8, total: 0, totalPages: 0 };

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ total: 0, active: 0, done: 0, overdue: 0 });
  const [pagination, setPagination] = useState(initialPagination);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [priority, setPriority] = useState('all');
  const [page, setPage] = useState(1);
  const [refreshKey, setRefreshKey] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError('');
    Promise.all([
      taskApi.list({ q: debouncedSearch, status, priority, page, limit: 8 }),
      taskApi.stats()
    ]).then(([listResult, statsResult]) => {
      if (!alive) return;
      setTasks(listResult.data);
      setPagination(listResult.pagination);
      setStats(statsResult.data);
    }).catch((err) => {
      if (alive) setError(err.message);
    }).finally(() => {
      if (alive) setLoading(false);
    });
    return () => { alive = false; };
  }, [debouncedSearch, status, priority, page, refreshKey]);

  function changeSearch(value) { setSearch(value); setPage(1); }
  function changeStatus(value) { setStatus(value); setPage(1); }
  function changePriority(value) { setPriority(value); setPage(1); }
  function refresh() { setRefreshKey((key) => key + 1); }
  function openCreate() { setEditingTask(null); setFormError(''); setModalOpen(true); }
  function openEdit(task) { setEditingTask(task); setFormError(''); setModalOpen(true); }

  async function saveTask(payload) {
    setFormError('');
    setSaving(true);
    try {
      if (editingTask) await taskApi.update(editingTask.id, payload);
      else await taskApi.create(payload);
      setModalOpen(false);
      setPage(1);
      refresh();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function toggleTask(task) {
    setBusyId(task.id);
    setError('');
    try {
      await taskApi.update(task.id, { completed: !task.completed });
      refresh();
    } catch (err) { setError(err.message); }
    finally { setBusyId(null); }
  }

  async function deleteTask(task) {
    if (!window.confirm(`Xóa công việc “${task.title}”? Thao tác này không thể hoàn tác.`)) return;
    setBusyId(task.id);
    setError('');
    try {
      await taskApi.remove(task.id);
      if (tasks.length === 1 && page > 1) setPage((value) => value - 1);
      else refresh();
    } catch (err) { setError(err.message); }
    finally { setBusyId(null); }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-icon">✓</div><span>Task<span className="brand-accent">Flow</span></span></div>
        <p className="nav-caption">WORKSPACE</p>
        <a className="nav-item active" href="#overview"><span>▦</span> Tổng quan</a>
        <a className="nav-item" href="#tasks"><span>☑</span> Công việc</a>
        <div className="sidebar-bottom">
          <div className="sidebar-tip"><strong>Focus on progress.</strong><p>Mỗi công việc hoàn thành là một bước tiến.</p></div>
          <span className="sidebar-version">React · Express · PostgreSQL</span>
        </div>
      </aside>
      <main className="main-content">
        <header className="topbar"><div className="mobile-brand">TaskFlow</div><div className="topbar-right"><span className="live-dot" /> Task Management Workspace <span className="avatar">TF</span></div></header>
        <div className="content-container">
          <div className="page-heading" id="overview">
            <div><span className="eyebrow">YOUR WORKSPACE</span><h1>Quản lý công việc<span className="heading-period">.</span></h1><p>Tập trung, sắp xếp ưu tiên và hoàn thành mục tiêu mỗi ngày.</p></div>
            <button className="button button-primary add-button" onClick={openCreate}><span aria-hidden="true">＋</span> Thêm công việc</button>
          </div>
          <section className="stats-grid" aria-label="Thống kê công việc">
            {[
              { label: 'Tổng công việc', value: stats.total, icon: '▦', tone: 'blue' },
              { label: 'Đang thực hiện', value: stats.active, icon: '◷', tone: 'amber' },
              { label: 'Đã hoàn thành', value: stats.done, icon: '✓', tone: 'green' },
              { label: 'Quá hạn', value: stats.overdue, icon: '!', tone: 'red' }
            ].map((item) => <div className="stat-card" key={item.label}>
              <div className={`stat-icon tone-${item.tone}`}>{item.icon}</div>
              <div><div className="stat-number">{item.value}</div><div className="stat-label">{item.label}</div></div>
            </div>)}
          </section>
          <section className="task-section" id="tasks">
            <div className="section-heading"><div><h2>Danh sách công việc</h2><p>{pagination.total} kết quả phù hợp</p></div><span className="section-badge">Tasks</span></div>
            <div className="filters">
              <div className="search-field"><span aria-hidden="true">⌕</span><input aria-label="Tìm kiếm công việc" placeholder="Tìm theo tên hoặc mô tả..." value={search} onChange={(event) => changeSearch(event.target.value)} /></div>
              <select aria-label="Lọc trạng thái" value={status} onChange={(event) => changeStatus(event.target.value)}>
                <option value="all">Mọi trạng thái</option><option value="active">Đang thực hiện</option><option value="done">Đã hoàn thành</option>
              </select>
              <select aria-label="Lọc mức ưu tiên" value={priority} onChange={(event) => changePriority(event.target.value)}>
                <option value="all">Mọi ưu tiên</option><option value="high">Ưu tiên cao</option><option value="medium">Trung bình</option><option value="low">Ưu tiên thấp</option>
              </select>
            </div>
            {error && <div className="notice error-notice" role="alert">{error} <button className="inline-retry" onClick={refresh}>Thử lại</button></div>}
            {loading ? <div className="empty-state" role="status">Đang tải dữ liệu từ PostgreSQL…</div>
              : !error && tasks.length === 0 ? <div className="empty-state"><div className="empty-icon">☑</div><h3>Chưa có công việc phù hợp</h3><p>Hãy tạo công việc mới hoặc thay đổi bộ lọc.</p><button className="button button-primary" onClick={openCreate}>＋ Tạo công việc</button></div>
              : <div className="task-list">{tasks.map((task) => <TaskCard key={task.id} task={task}
                busy={busyId === task.id} onToggle={toggleTask} onEdit={openEdit} onDelete={deleteTask} />)}</div>}
            <div className="pagination"><span>Trang {pagination.page} / {Math.max(1, pagination.totalPages)}</span><div>
              <button className="button button-ghost" disabled={loading || page <= 1} onClick={() => setPage((p) => p - 1)}>← Trước</button>
              <button className="button button-ghost" disabled={loading || page >= pagination.totalPages} onClick={() => setPage((p) => p + 1)}>Tiếp →</button>
            </div></div>
          </section>
          <footer className="footer">TaskFlow · Full-stack demo · React + Express.js + PostgreSQL</footer>
        </div>
      </main>
      {modalOpen && <TaskForm task={editingTask} saving={saving} error={formError} onSave={saveTask} onClose={() => setModalOpen(false)} />}
    </div>
  );
}
