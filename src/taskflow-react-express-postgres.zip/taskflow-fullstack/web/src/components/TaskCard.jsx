const priorities = {
  low: ['Thấp', 'low'],
  medium: ['Trung bình', 'medium'],
  high: ['Cao', 'high']
};

function displayDate(value) {
  if (!value) return null;
  return new Date(`${value}T12:00:00`).toLocaleDateString('vi-VN');
}

export default function TaskCard({ task, busy, onToggle, onEdit, onDelete }) {
  const priority = priorities[task.priority] || priorities.medium;
  const now = new Date();
  const localToday = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const isOverdue = !task.completed && task.due_date && task.due_date < localToday;
  return (
    <article className={`task-card ${task.completed ? 'task-done' : ''}`}>
      <input className="task-check" type="checkbox" checked={task.completed}
        disabled={busy} aria-label={`Đánh dấu hoàn thành: ${task.title}`}
        onChange={() => onToggle(task)} />
      <div className="task-body">
        <div className="task-head">
          <h3>{task.title}</h3>
          <span className={`priority priority-${priority[1]}`}>{priority[0]}</span>
        </div>
        {task.description && <p className="task-description">{task.description}</p>}
        <div className="task-meta">
          <span>#{task.id}</span>
          {task.due_date && <span className={isOverdue ? 'overdue' : ''}>
            ◷ {isOverdue ? 'Quá hạn · ' : 'Hạn · '}{displayDate(task.due_date)}
          </span>}
          {task.completed && <span className="completed-label">✓ Đã hoàn thành</span>}
        </div>
      </div>
      <div className="task-actions">
        <button className="icon-button" aria-label={`Sửa ${task.title}`} title="Chỉnh sửa" onClick={() => onEdit(task)} disabled={busy}>✎</button>
        <button className="icon-button danger" aria-label={`Xóa ${task.title}`} title="Xóa" onClick={() => onDelete(task)} disabled={busy}>✕</button>
      </div>
    </article>
  );
}
