import { useEffect, useState } from 'react';

const empty = { title: '', description: '', priority: 'medium', due_date: '', completed: false };

export default function TaskForm({ task, saving, error, onSave, onClose }) {
  const [form, setForm] = useState(empty);
  useEffect(() => {
    setForm(task ? {
      title: task.title,
      description: task.description,
      priority: task.priority,
      due_date: task.due_date || '',
      completed: task.completed
    } : empty);
  }, [task]);

  function update(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event) {
    event.preventDefault();
    onSave({
      title: form.title.trim(),
      description: form.description.trim(),
      priority: form.priority,
      due_date: form.due_date || null,
      completed: form.completed
    });
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => {
      if (event.target === event.currentTarget && !saving) onClose();
    }}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="task-dialog-title">
        <div className="modal-heading">
          <div>
            <span className="eyebrow">TASK DETAILS</span>
            <h2 id="task-dialog-title">{task ? 'Chỉnh sửa công việc' : 'Thêm công việc mới'}</h2>
          </div>
          <button type="button" className="icon-button" aria-label="Đóng" onClick={onClose} disabled={saving}>✕</button>
        </div>
        <form onSubmit={submit} className="task-form">
          <label>Tên công việc <span aria-hidden="true">*</span>
            <input autoFocus required maxLength={120} value={form.title}
              onChange={(event) => update('title', event.target.value)} placeholder="Ví dụ: Hoàn thành báo cáo" />
          </label>
          <label>Mô tả
            <textarea rows={3} maxLength={2000} value={form.description}
              onChange={(event) => update('description', event.target.value)} placeholder="Ghi chú hoặc chi tiết công việc..." />
          </label>
          <div className="form-grid">
            <label>Mức ưu tiên
              <select value={form.priority} onChange={(event) => update('priority', event.target.value)}>
                <option value="low">Thấp</option>
                <option value="medium">Trung bình</option>
                <option value="high">Cao</option>
              </select>
            </label>
            <label>Hạn hoàn thành
              <input type="date" value={form.due_date}
                onChange={(event) => update('due_date', event.target.value)} />
            </label>
          </div>
          <label className="checkbox-label"><input type="checkbox" checked={form.completed}
            onChange={(event) => update('completed', event.target.checked)} /> Đã hoàn thành</label>
          {error && <div className="form-error" role="alert">{error}</div>}
          <div className="form-actions">
            <button type="button" className="button button-ghost" onClick={onClose} disabled={saving}>Hủy</button>
            <button className="button button-primary" type="submit" disabled={saving}>
              {saving ? 'Đang lưu…' : task ? 'Lưu thay đổi' : 'Tạo công việc'}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
