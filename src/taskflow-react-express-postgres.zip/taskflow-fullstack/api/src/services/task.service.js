import { taskRepository } from '../repositories/task.repository.js';
import { AppError } from '../middleware/error.js';

export const taskService = {
  async list(query) {
    const { items, total } = await taskRepository.findMany(query);
    return {
      items,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit)
      }
    };
  },
  stats: () => taskRepository.stats(),
  async get(id) {
    const task = await taskRepository.findById(id);
    if (!task) throw new AppError(404, 'Task not found');
    return task;
  },
  create: (body) => taskRepository.create(body),
  async update(id, body) {
    const task = await taskRepository.update(id, body);
    if (!task) throw new AppError(404, 'Task not found');
    return task;
  },
  async remove(id) {
    if (!await taskRepository.remove(id)) throw new AppError(404, 'Task not found');
  }
};
