import { Router } from 'express';
import { taskController } from '../controllers/task.controller.js';
import { validate } from '../middleware/validate.js';
import { paramsSchema, listSchema, createSchema, updateSchema } from '../schemas/task.schema.js';

const router = Router();
router.get('/', validate(listSchema, 'query'), taskController.list);
router.get('/stats', taskController.stats); // Before /:id
router.get('/:id', validate(paramsSchema, 'params'), taskController.get);
router.post('/', validate(createSchema), taskController.create);
router.patch('/:id', validate(paramsSchema, 'params'), validate(updateSchema), taskController.update);
router.delete('/:id', validate(paramsSchema, 'params'), taskController.remove);
export default router;
