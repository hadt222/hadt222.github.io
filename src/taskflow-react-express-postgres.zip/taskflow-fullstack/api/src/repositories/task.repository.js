import { pool } from '../config/db.js';

const columns = `id, title, description, priority, due_date::text AS due_date,
                 completed, created_at, updated_at`;

const filterSql = `
  WHERE ($1::text IS NULL
    OR POSITION(LOWER($1) IN LOWER(title)) > 0
    OR POSITION(LOWER($1) IN LOWER(description)) > 0)
    AND ($2::text = 'all'
      OR ($2::text = 'done' AND completed = TRUE)
      OR ($2::text = 'active' AND completed = FALSE))
    AND ($3::text = 'all' OR priority = $3)
`;

export const taskRepository = {
  async findMany({ q, status, priority, page, limit }) {
    const filters = [q || null, status, priority];
    const offset = (page - 1) * limit;
    const [itemsResult, countResult] = await Promise.all([
      pool.query(
        `SELECT ${columns} FROM tasks ${filterSql}
         ORDER BY created_at DESC, id DESC LIMIT $4 OFFSET $5`,
        [...filters, limit, offset]
      ),
      pool.query(`SELECT COUNT(*)::int AS total FROM tasks ${filterSql}`, filters)
    ]);
    return { items: itemsResult.rows, total: countResult.rows[0].total };
  },

  async stats() {
    const result = await pool.query(`
      SELECT COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE completed = TRUE)::int AS done,
        COUNT(*) FILTER (WHERE completed = FALSE)::int AS active,
        COUNT(*) FILTER (WHERE completed = FALSE AND due_date < CURRENT_DATE)::int AS overdue
      FROM tasks
    `);
    return result.rows[0];
  },

  async findById(id) {
    const result = await pool.query(`SELECT ${columns} FROM tasks WHERE id = $1`, [id]);
    return result.rows[0] ?? null;
  },

  async create({ title, description, priority, due_date, completed }) {
    const result = await pool.query(
      `INSERT INTO tasks (title, description, priority, due_date, completed)
       VALUES ($1, $2, $3, $4, $5) RETURNING ${columns}`,
      [title, description, priority, due_date, completed]
    );
    return result.rows[0];
  },

  async update(id, changes) {
    const permitted = ['title', 'description', 'priority', 'due_date', 'completed'];
    const entries = permitted.filter((key) => Object.hasOwn(changes, key));
    const assignments = entries.map((key, i) => `${key} = $${i + 1}`);
    assignments.push('updated_at = NOW()');
    const values = [...entries.map((key) => changes[key]), id];
    const result = await pool.query(
      `UPDATE tasks SET ${assignments.join(', ')}
       WHERE id = $${values.length} RETURNING ${columns}`,
      values
    );
    return result.rows[0] ?? null;
  },

  async remove(id) {
    const result = await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
    return result.rowCount > 0;
  }
};
