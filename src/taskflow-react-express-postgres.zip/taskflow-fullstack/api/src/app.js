import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { pool } from './config/db.js';
import taskRoutes from './routes/task.routes.js';
import { AppError, notFound, errorHandler } from './middleware/error.js';

const app = express();
const origins = (process.env.FRONTEND_ORIGIN || 'http://localhost:5173')
  .split(',').map((value) => value.trim()).filter(Boolean);

app.disable('x-powered-by');
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || origins.includes(origin)) callback(null, true);
    else callback(new AppError(403, 'Origin not allowed'));
  }
}));
app.use(express.json({ limit: '100kb' }));
app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.get('/ready', async (req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ready' });
});
app.use('/api/tasks', taskRoutes);
app.use(notFound);
app.use(errorHandler);

export default app;
