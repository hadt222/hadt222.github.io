import { z } from 'zod';

const idSchema = z.string().regex(/^[1-9]\d*$/).transform(Number)
  .pipe(z.int().min(1).max(2147483647));

const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((value) => {
    const date = new Date(`${value}T00:00:00.000Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }, 'Date must be valid and formatted YYYY-MM-DD');

const taskFields = {
  title: z.string().trim().min(1).max(120),
  description: z.string().trim().max(2000),
  priority: z.enum(['low', 'medium', 'high']),
  due_date: dateSchema.nullable(),
  completed: z.boolean()
};

const positiveIntQuery = (max, defaultValue) => z.coerce.number()
  .int().min(1).max(max).default(defaultValue);

export const paramsSchema = z.strictObject({ id: idSchema });
export const listSchema = z.strictObject({
  q: z.string().trim().max(100).optional(),
  status: z.enum(['all', 'active', 'done']).default('all'),
  priority: z.enum(['all', 'low', 'medium', 'high']).default('all'),
  page: positiveIntQuery(100000, 1),
  limit: positiveIntQuery(50, 8)
});
export const createSchema = z.strictObject({
  title: taskFields.title,
  description: taskFields.description.default(''),
  priority: taskFields.priority.default('medium'),
  due_date: taskFields.due_date.default(null),
  completed: taskFields.completed.default(false)
});
export const updateSchema = z.strictObject({
  title: taskFields.title.optional(),
  description: taskFields.description.optional(),
  priority: taskFields.priority.optional(),
  due_date: taskFields.due_date.optional(),
  completed: taskFields.completed.optional()
}).refine((value) => Object.keys(value).length > 0, 'At least one field is required');
