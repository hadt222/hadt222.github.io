import 'dotenv/config';
import { Pool } from 'pg';

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required');
}

// Tests must never touch the development or production database.
if (process.env.NODE_ENV === 'test') {
  const database = decodeURIComponent(new URL(process.env.DATABASE_URL).pathname.slice(1));
  if (!database.endsWith('_test')) {
    throw new Error('A test database must have a name ending with _test');
  }
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000
});

pool.on('error', (error) => {
  console.error('Unexpected idle PostgreSQL client error', error);
});
