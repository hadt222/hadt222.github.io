import { taskService } from '../services/task.service.js';

export const taskController = {
  async list(req, res) {
    const { items, pagination } = await taskService.list(res.locals.validated.query);
    res.json({ success: true, data: items, pagination });
  },
  async stats(req, res) {
    res.json({ success: true, data: await taskService.stats() });
  },
  async get(req, res) {
    const task = await taskService.get(res.locals.validated.params.id);
    res.json({ success: true, data: task });
  },
  async create(req, res) {
    const task = await taskService.create(res.locals.validated.body);
    res.location(`/api/tasks/${task.id}`).status(201).json({ success: true, data: task });
  },
  async update(req, res) {
    const task = await taskService.update(
      res.locals.validated.params.id, res.locals.validated.body
    );
    res.json({ success: true, data: task });
  },
  async remove(req, res) {
    await taskService.remove(res.locals.validated.params.id);
    res.status(204).end();
  }
};
