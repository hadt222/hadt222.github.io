export class AppError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export function notFound(req, res) {
  res.status(404).json({ success: false, error: { message: 'Route not found' } });
}

export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const status = Number.isInteger(err.status) && err.status >= 400 && err.status < 600
    ? err.status : 500;
  if (status >= 500) console.error(err);
  const message = err.type === 'entity.parse.failed'
    ? 'Invalid JSON body'
    : status >= 500 ? 'Internal server error' : err.message;
  res.status(status).json({
    success: false,
    error: {
      message,
      ...(status < 500 && err.details ? { details: err.details } : {})
    }
  });
}
