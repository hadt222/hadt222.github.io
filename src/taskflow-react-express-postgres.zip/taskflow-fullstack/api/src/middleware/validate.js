import { AppError } from './error.js';

export const validate = (schema, location = 'body') => (req, res, next) => {
  const result = schema.safeParse(req[location]);
  if (!result.success) {
    throw new AppError(400, 'Invalid request data', result.error.issues.map((issue) => ({
      field: issue.path.join('.') || location,
      message: issue.message
    })));
  }
  res.locals.validated ??= {};
  res.locals.validated[location] = result.data;
  next();
};
