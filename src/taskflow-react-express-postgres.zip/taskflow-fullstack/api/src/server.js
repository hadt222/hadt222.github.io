import app from './app.js';
import { pool } from './config/db.js';

const port = Number(process.env.PORT || 4000);
const server = app.listen(port, '0.0.0.0', () => {
  console.log(`TaskFlow API listening on port ${port}`);
});

async function shutdown(signal) {
  console.log(`${signal} received, shutting down`);
  server.close(async () => {
    try { await pool.end(); process.exit(0); }
    catch (error) { console.error(error); process.exit(1); }
  });
  // Avoid hanging indefinitely on existing connections.
  server.closeIdleConnections?.();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
