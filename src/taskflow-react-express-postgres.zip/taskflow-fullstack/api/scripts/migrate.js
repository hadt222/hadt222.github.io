import 'dotenv/config';
import { readFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { pool } from '../src/config/db.js';

const directory = join(dirname(fileURLToPath(import.meta.url)), '../db/migrations');
const files = (await readdir(directory)).filter((file) => file.endsWith('.sql')).sort();
const client = await pool.connect();

try {
  await client.query('BEGIN');
  // Serialize competing migrations from multiple deploys/processes.
  await client.query('SELECT pg_advisory_xact_lock(902101)');
  await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    filename TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);

  for (const file of files) {
    const exists = await client.query(
      'SELECT 1 FROM schema_migrations WHERE filename = $1', [file]
    );
    if (exists.rowCount) {
      console.log(`Already applied: ${file}`);
      continue;
    }
    await client.query(await readFile(join(directory, file), 'utf8'));
    await client.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
    console.log(`Applied: ${file}`);
  }
  await client.query('COMMIT');
} catch (error) {
  await client.query('ROLLBACK');
  console.error('Migration failed:', error);
  process.exitCode = 1;
} finally {
  client.release();
  await pool.end();
}
