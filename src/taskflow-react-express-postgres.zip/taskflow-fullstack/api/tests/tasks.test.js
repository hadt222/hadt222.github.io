import { beforeEach, after, test } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../src/app.js';
import { pool } from '../src/config/db.js';

// This test suite requires task_manager_test, migrated with db:migrate:test.
beforeEach(async () => {
  await pool.query('TRUNCATE TABLE tasks RESTART IDENTITY');
});
after(async () => { await pool.end(); });

test('health/readiness endpoints', async () => {
  await request(app).get('/health').expect(200);
  await request(app).get('/ready').expect(200);
});

test('create, get, patch and delete a task', async () => {
  const created = await request(app).post('/api/tasks').send({
    title: 'Write tests', description: 'End to end API', priority: 'high', due_date: '2027-01-31'
  }).expect(201);
  const id = created.body.data.id;
  assert.equal(created.body.data.title, 'Write tests');
  assert.equal(created.body.data.due_date, '2027-01-31');
  const fetched = await request(app).get(`/api/tasks/${id}`).expect(200);
  assert.equal(fetched.body.data.priority, 'high');
  const updated = await request(app).patch(`/api/tasks/${id}`)
    .send({ completed: true }).expect(200);
  assert.equal(updated.body.data.completed, true);
  await request(app).delete(`/api/tasks/${id}`).expect(204);
  await request(app).get(`/api/tasks/${id}`).expect(404);
});

test('search, filter, pagination and statistics', async () => {
  await request(app).post('/api/tasks').send({ title: 'Learn React', completed: true }).expect(201);
  await request(app).post('/api/tasks').send({ title: 'Learn SQL', priority: 'high' }).expect(201);
  const result = await request(app).get('/api/tasks?q=Learn&status=active&priority=high&page=1&limit=2').expect(200);
  assert.equal(result.body.pagination.total, 1);
  assert.equal(result.body.data[0].title, 'Learn SQL');
  const stats = await request(app).get('/api/tasks/stats').expect(200);
  assert.equal(stats.body.data.total, 2);
  assert.equal(stats.body.data.done, 1);
  assert.equal(stats.body.data.active, 1);
});

test('invalid requests are rejected', async () => {
  await request(app).post('/api/tasks').send({ title: '' }).expect(400);
  await request(app).post('/api/tasks').send({ title: 'X', priority: 'urgent' }).expect(400);
  await request(app).post('/api/tasks').send({ title: 'X', due_date: '2027-02-30' }).expect(400);
  await request(app).get('/api/tasks?page=0').expect(400);
  await request(app).get('/api/tasks/abc').expect(400);
  await request(app).patch('/api/tasks/1').send({}).expect(400);
});
